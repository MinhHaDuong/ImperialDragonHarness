# AI-assisted Forensic Commentary Template (I4R)

LaTeX version of the I4R AI-assisted forensic commentary template.

## Requirements

- **TeX Live 2025 or newer**, or an up-to-date MiKTeX (needed for PDF tagging via `\DocumentMetadata`)
- **LuaLaTeX** as the engine (pdfLaTeX will not work)
- **Biber** with **biblatex** and **biblatex-apa**

A full TeX Live installation includes all of these. Overleaf needs no installation (see [Building](#building)).

## Installing

**macOS:** install [MacTeX](https://tug.org/mactex/), the full TeX Live for macOS 11 or newer (about 6 GB). With Homebrew:

```bash
brew install --cask mactex-no-gui
```

Avoid the smaller BasicTeX: it leaves out many of the packages this template needs.

**Windows:** install TeX Live with [install-tl-windows.exe](https://tug.org/texlive/acquire-netinstall.html) and keep the default full scheme. The download can take a few hours. It includes everything above, latexmk too.

MiKTeX should also work (`winget install -e --id MiKTeX.MiKTeX`). Update it first (MiKTeX Console → Updates); it installs missing packages during the first build. Its latexmk needs a separate Perl such as [Strawberry Perl](https://strawberryperl.com/); without Perl, use the commands under *Locally without latexmk*.

**Linux:** distribution packages are only recent enough on Ubuntu 26.04 or newer and Debian testing. There:

```bash
sudo apt install texlive-luatex texlive-latex-extra texlive-science texlive-bibtex-extra biber latexmk
```

Older releases, including Ubuntu 24.04 LTS and Debian 13, ship TeX Live 2023 or 2024. On those, install TeX Live directly with the official [quick install guide](https://tug.org/texlive/quickinstall.html).

## Building

**Overleaf:** upload `main.tex` and `references.bib`, then set Menu → Settings → Compiler to *LuaLaTeX* and TeX Live version to *2025* or newer.

**Locally with latexmk:**

```bash
latexmk -lualatex main.tex
```

**Locally without latexmk:**

```bash
lualatex main
biber main
lualatex main
lualatex main
```

**In an editor** (TeXstudio, VS Code LaTeX Workshop, TeXShop, …): set the compiler to *LuaLaTeX* and the bibliography tool to *Biber*.

## Using the template

Blue text is guidance. Set `\showinstructionsfalse` in `main.tex` to hide it, along with the front page, once the report is filled in.
